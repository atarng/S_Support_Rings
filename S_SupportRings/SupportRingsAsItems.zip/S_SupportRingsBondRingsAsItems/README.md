How to install SupportRings as Items
Add/Replace files in appropriate places.
